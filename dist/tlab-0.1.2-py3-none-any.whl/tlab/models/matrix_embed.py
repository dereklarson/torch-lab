"""Simple MLP
"""
from dataclasses import asdict, dataclass
from typing import List, Tuple

import einops
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from tlab.models.beta_components import BilinearLayer
from tlab.models.lab_model import LabModel
from tlab.utils.hookpoint import HookPoint


class MatrixEmbed(LabModel):
    @dataclass
    class Config(LabModel.Config):
        n_vocab: int
        shape_embed: Tuple[int, int]
        n_ctx: int = 2
        # n_outputs: int
        # layers: Tuple[int, ...]
        # use_bias: bool = True
        # activation_type: str = "ReLU"

    def __init__(self, cfg: Config):
        super().__init__(cfg)
        norm = np.sqrt(np.prod(cfg.shape_embed))
        self.embed = nn.Parameter(torch.randn(cfg.n_vocab, *cfg.shape_embed) / norm)

        # layers = []
        # for n_out in cfg.layers:
        #     layers.append(BilinearLayer(n_in, n_out, use_bias=cfg.use_bias))
        # self.layers = nn.ModuleList(layers)

        self._init_hooks()

    def forward(self, x):
        # Embed into matrices: (batch, x, row, col)
        x = self.embed[x, :]

        # TODO Temporary, multiply first and second context elements
        x = x[:, 0] @ x[:, 1]

        # Multiply by the transposes of embedding matrices
        # x = x.unsqueeze(1) @ einops.rearrange(self.embed, "v r c -> v c r")
        x = torch.sum(x.unsqueeze(1) * self.embed, dim=(2, 3))
        return x
