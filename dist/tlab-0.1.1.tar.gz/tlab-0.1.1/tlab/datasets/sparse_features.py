"""Methods for generating synthetic data.
"""
from dataclasses import asdict, dataclass

import numpy as np
import torch
import torch.nn.functional as F

from tlab.datasets.lab_dataset import DataBatch, LabDataset


class SparseFeatures(LabDataset):
    @dataclass
    class Config(LabDataset.Config):
        train_samples: int = 1000
        n_features: int = 10000
        p_active: float = 0.001
        use_choice: bool = False

    def __init__(
        self,
        cfg: Config,
    ) -> None:
        super().__init__(cfg)

        full_feat = np.random.rand(cfg.train_samples * 2, cfg.n_features)
        if cfg.use_choice:
            count = int(cfg.train_samples * cfg.p_active)
            if count < cfg.train_samples * cfg.p_active:
                print(f"Warning: use_choice=True with fractional feature activation.")
            mask = np.ones((cfg.train_samples * 2, cfg.n_features))
            for idx in range(cfg.n_features):
                active_idxs = np.random.choice(cfg.train_samples, count, replace=False)
                mask[active_idxs, idx] = 0
            for idx in range(cfg.n_features):
                active_idxs = np.random.choice(cfg.train_samples, count, replace=False)
                active_idxs += cfg.train_samples
                mask[active_idxs, idx] = 0
        else:
            mask = np.random.rand(cfg.train_samples * 2, cfg.n_features)

        full_feat = torch.tensor(full_feat, dtype=torch.float).to(cfg.device)
        mask = torch.tensor(mask, dtype=torch.float).to(cfg.device)

        features = torch.where(mask <= cfg.p_active, full_feat, torch.zeros(()))
        self.train = F.normalize(features[: cfg.train_samples]).to(cfg.device)
        self.val = F.normalize(features[cfg.train_samples :]).to(cfg.device)

    def get_batch(self, split: str) -> DataBatch:
        if split == "train":
            return DataBatch(self.train, self.train)
        else:
            return DataBatch(self.val, self.val)

    @property
    def val_loader(self):
        return [self.get_batch("val")]
